#!/bin/bash
# Corre todas las pruebas de la MV y compara la salida con la esperada.
# Uso:  ./pruebas_mv2/run_tests.sh [ruta_al_ejecutable]
#       Por defecto usa ../vmx.exe (Windows) o ../vmx (Linux / Codespaces).
#       En Windows correrlo desde una terminal "Git Bash".
cd "$(dirname "$0")"
if [ -n "$1" ]; then VMX=$1
else
    case "$(uname -s)" in
        MINGW*|MSYS*|CYGWIN*) VMX=../vmx.exe ;;   # Git Bash en Windows
        *)                    VMX=../vmx ;;       # Linux / Codespaces
    esac
fi
echo "Probando: $VMX"
ok=0; mal=0

prueba() {   # prueba <nombre> <entrada por teclado> <argumentos...>
    local nombre=$1 entrada=$2; shift 2
    local obtenido
    obtenido=$(printf '%b' "$entrada" | timeout 10 "$VMX" "$@" 2>&1 | tr -d '\r')
    if [ "$obtenido" == "$(cat esperado/$nombre.txt)" ]; then
        echo "  OK     $nombre"; ok=$((ok+1))
    else
        echo "  FALLA  $nombre   ($VMX $*)"
        echo "           (< lo que dio la MV,  > lo esperado)"
        diff <(echo "$obtenido") esperado/$nombre.txt | sed 's/^/           /'
        mal=$((mal+1))
    fi
}

echo "== Compatibilidad v1 (samples de la catedra)"
prueba sample          ""  casos/sample.vmx
prueba sample_1        ""  casos/sample_1.vmx
prueba sample_2        ""  casos/sample_2.vmx
prueba sample_d        ""  casos/sample.vmx -d
prueba sample_3_10     "10\n"   casos/sample_3.vmx
prueba sample_3_255    "255\n"  casos/sample_3.vmx
prueba sample_3_neg    "-1\n"   casos/sample_3.vmx
prueba sample_7        ""  casos/sample_7.vmx
prueba sample_7_d      ""  casos/sample_7.vmx -d
prueba v1_con_param    ""  casos/sample_7.vmx -p hola

echo "== Instrucciones y operandos v2"
prueba t01_factorial      ""  casos/t01_factorial.vmx
prueba t02_sectores       ""  casos/t02_sectores.vmx
prueba t03_modificadores  ""  casos/t03_modificadores.vmx
prueba t15_call_indirecto ""  casos/t15_call_indirecto.vmx

echo "== Strings, constantes y disassembler"
prueba t04_strings_d      ""  casos/t04_strings.vmx -d
prueba t05_leer_string    "Hola mundo\nsin limite\n"  casos/t05_leer_string.vmx
prueba t13_sin_main_d     ""  casos/t13_sin_main.vmx -d

echo "== Parametros (-p), pila inicial y memoria (m=)"
prueba t06_con_param      ""  casos/t06_parametros.vmx -p prueba 01 2
prueba t06_sin_param      ""  casos/t06_parametros.vmx
prueba t01_m1             ""  casos/t01_factorial.vmx m=1
prueba t01_m4             ""  casos/t01_factorial.vmx m=4

echo "== Errores"
prueba t07_stack_overflow  ""  casos/t07_stack_overflow.vmx
prueba t08_stack_underflow ""  casos/t08_stack_underflow.vmx
prueba t09_div_cero        ""  casos/t09_div_cero.vmx
prueba t10_segmento        ""  casos/t10_segmento.vmx
prueba t11_sin_pila        ""  casos/t11_sin_pila.vmx
prueba err_m_invalido      ""  casos/t01_factorial.vmx m=abc
prueba err_sin_archivo     ""

echo "== Breakpoint e imagen (.vmi)"
rm -f casos/img.vmi
prueba t12_break_q         "q\n"         casos/t12_breakpoint.vmx casos/img.vmi
prueba t12_continuar_vmi   "g\n"         casos/img.vmi
rm -f casos/img.vmi
prueba t12_paso_a_paso     "\n\n\ng\n"   casos/t12_breakpoint.vmx casos/img.vmi
prueba t12_sin_vmi         ""            casos/t12_breakpoint.vmx
rm -f casos/img.vmi
prueba t14_leer_y_break_q  "42\ntexto\nq\n"  casos/t14_leer_y_break.vmx casos/img.vmi
rm -f casos/img.vmi
prueba t14_leer_y_break_g  "42\ntexto\ng\n"  casos/t14_leer_y_break.vmx casos/img.vmi
rm -f casos/img.vmi
prueba t16_v1_break_q      "q\n"   casos/t16_v1_break.vmx casos/img.vmi
prueba t16_v1_continuar    "g\n"   casos/img.vmi
rm -f casos/img.vmi

echo
echo "Resultado: $ok OK, $mal con fallas"
[ $mal -eq 0 ]

# Pruebas de la MV2 (36 casos)

## Cómo correrlas todas

Copiar la carpeta `pruebas_mv2` adentro del repo (al lado de `Main.c`) y, desde la raíz del repo:

**En el Codespace (Linux):**

    gcc *.c -o vmx
    bash pruebas_mv2/run_tests.sh

**En Windows** (terminal de VS Code con el perfil **Git Bash**, no PowerShell):

    gcc *.c -o vmx.exe
    bash pruebas_mv2/run_tests.sh

Al final dice `Resultado: N OK, M con fallas`. Si alguna falla, muestra las líneas distintas
(`<` lo que dio la MV, `>` lo esperado). También se le puede pasar la ruta del ejecutable:
`bash pruebas_mv2/run_tests.sh ./otro_vmx`.

## Correr una prueba suelta (PowerShell)

    .\vmx.exe pruebas_mv2\casos\t01_factorial.vmx -d
    .\vmx.exe pruebas_mv2\casos\t06_parametros.vmx -p prueba 01 2
    .\vmx.exe pruebas_mv2\casos\t01_factorial.vmx m=1
    .\vmx.exe pruebas_mv2\casos\sample_3.vmx                (pide un número por teclado)

Breakpoint + debugger de la cátedra (dos terminales):

    terminal 1:  .\vmx.exe pruebas_mv2\casos\t12_breakpoint.vmx img.vmi
    terminal 2:  .\vmg.exe img.vmi -r -s
    (en la terminal 1: Enter = paso a paso, g = continuar, q = salir)
    para retomar después de una q:  .\vmx.exe img.vmi

En el Codespace es igual pero con `./vmx` y `/` en las rutas.

## Las pruebas

| Prueba | Qué verifica |
|---|---|
| `sample`, `sample_1`, `sample_2`, `sample_3_*`, `sample_7` | programas v1 de la cátedra: dan **lo mismo que la MV1 entregada** (`sample_3` cuenta los bits en 1 del número ingresado) |
| `sample_d`, `sample_7_d` | disassembler de programas v1 |
| `v1_con_param` | un programa v1 ignora `-p` |
| `t01_factorial` | CALL/RET recursivo, PUSH/POP, parámetros por pila con BP, `main` → 120 |
| `t02_sectores` | AL/AH/AX (extensión de signo, no pisar el resto) y el ejemplo `PUSH AX` / `POP w[ES+4]` del PDF |
| `t03_modificadores` | `b[]` `w[]` `l[]`: big endian, truncado, extensión de signo; ejemplo `MOV w[2], l[10]` |
| `t15_call_indirecto` | CALL con rótulo, con registro y con memoria |
| `t04_strings_d` | constantes del KS en el disassembler (`..` en las largas, `.` en no imprimibles) y SYS 4 |
| `t05_leer_string` | SYS 3 con límite (ECX = 4) y sin límite (ECX = -1) |
| `t13_sin_main_d` | sin `main` arranca en la primera instrucción; termina con `RET` |
| `t06_con_param` / `t06_sin_param` | Param Segment y pila inicial: `argc` y cada `argv[i]` |
| `t01_m1` / `t01_m4` | `m=1` → memoria insuficiente; `m=4` alcanza |
| `t07` … `t11`, `err_*` | stack overflow, stack underflow, división por cero, falla de segmento, header sin pila, `m=abc`, sin archivo |
| `t12_*` | breakpoint: `q` guarda la imagen, se retoma desde el `.vmi`, paso a paso con Enter, sin `.vmi` se ignora |
| `t14_*` | leer un número (SYS 1), después un string (SYS 3) y después un breakpoint |
| `t16_*` | programa **v1** con breakpoint y basura en los bits reservados: se guarda y se retoma bien |

`SYS 0` (limpiar pantalla) no está en el script porque borra la terminal: probarlo a mano.

## Para hacer más pruebas

`casos/*.asm` tiene el código de cada prueba, comentado. Con el traductor de la cátedra
(`vmt.exe`) o con `python3 pruebas_mv2/asm.py prueba.asm prueba.vmx` (agregar `v=1` para v1)
se generan nuevos `.vmx`.

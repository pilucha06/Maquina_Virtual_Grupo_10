#!/usr/bin/env python3
"""Mini-ensamblador para generar .vmx de prueba (MV1/MV2 2026).
Soporta: rotulos (main incluido), comentarios ';', directivas \\DATA \\EXTRA \\STACK,
constantes EQU (numericas y strings -> Const Segment), registros con sectores (EAX/AX/AL/AH),
memoria con modificador b/w/l y desplazamiento, inmediatos decimales/hex/char.
Uso: asm.py entrada.asm salida.vmx [v=1|v=2]"""
import sys, re

PRIMERA = True
OPC = {'SYS':0x00,'JMP':0x01,'JP':0x02,'JN':0x03,'JZ':0x04,'JC':0x05,'JV':0x06,'JNP':0x07,
       'JNN':0x08,'JNZ':0x09,'NOT':0x0A,'PUSH':0x0B,'POP':0x0C,'CALL':0x0D,'RET':0x0E,'STOP':0x0F,
       'MOV':0x10,'ADD':0x11,'SUB':0x12,'MUL':0x13,'DIV':0x14,'CMP':0x15,'AND':0x16,'OR':0x17,
       'XOR':0x18,'SWAP':0x19,'SHL':0x1A,'SHR':0x1B,'SAR':0x1C,'LDL':0x1D,'LDH':0x1E,'RND':0x1F}
REGS = {'IP':0,'OPC':1,'OP1':2,'OP2':3,'LAR':4,'MAR':5,'MBR':6,'SP':7,'BP':8,'AC':16,'CC':17,
        'CS':26,'DS':27,'ES':28,'SS':29,'KS':30,'PS':31}
for i, l in enumerate('ABCDEF'):
    REGS['E%sX' % l] = 10 + i

def reg(tok):
    t = tok.upper()
    if t in REGS:
        return REGS[t], 0
    m = re.fullmatch(r'([A-F])([XLH])', t)
    if m:
        return 10 + 'ABCDEF'.index(m.group(1)), {'L':1, 'H':2, 'X':3}[m.group(2)]
    return None

def num(tok, sym):
    t = tok.strip()
    if t in sym: return sym[t]
    if re.fullmatch(r"'.'", t): return ord(t[1])
    if t.lower().startswith('0x'): return int(t, 16)
    if t.lower().startswith('0b'): return int(t[2:], 2)
    if t.lower().startswith('0o'): return int(t[2:], 8)
    if re.fullmatch(r'[A-Za-z_]\w*', t):
        if PRIMERA: return 0                 # rotulo todavia desconocido (1ra pasada)
        raise SystemExit('simbolo desconocido: ' + t)
    return int(t)

def operando(tok, sym):
    tok = tok.strip()
    m = re.fullmatch(r'([bwlBWL]?)\[(.*)\]', tok)
    if m:                                   # memoria: 3 bytes
        tam = {'b':1, 'w':2, 'l':4, '':4}[m.group(1).lower()]
        dentro = m.group(2).replace(' ', '')
        mm = re.fullmatch(r'([A-Za-z]+)?([+-].+)?', dentro)
        r = reg(mm.group(1)) if mm and mm.group(1) and reg(mm.group(1)) else None
        if r is None:                       # [5] -> [DS+5]
            rc, desp = REGS['DS'], num(dentro, sym)
        else:
            rc = r[0]
            desp = 0
            if mm.group(2):
                desp = num(mm.group(2)[1:], sym) * (-1 if mm.group(2)[0] == '-' else 1)
        desp &= 0xFFFF
        return 3, [desp >> 8, desp & 0xFF, (tam << 5) | rc]
    r = reg(tok)
    if r:
        return 1, [(r[1] << 5) | r[0]]
    v = num(tok, sym) & 0xFFFF
    return 2, [v >> 8, v & 0xFF]

def parse(path):
    lineas, tams, consts, sym = [], {'DATA':1024, 'EXTRA':1024, 'STACK':1024}, b'', {}
    for raw in open(path, encoding='utf-8'):
        linea, dentro = '', False           # saca el comentario ';' que no este entre comillas
        for ch in raw.rstrip('\n'):
            if ch == '"': dentro = not dentro
            if ch == ';' and not dentro: break
            linea += ch
        if not linea.strip(): continue
        s = linea.strip()
        m = re.fullmatch(r'\\\\(DATA|EXTRA|STACK)\s+(\d+)', s, re.I)
        if m: tams[m.group(1).upper()] = int(m.group(2)); continue
        m = re.fullmatch(r'(\w+)\s+EQU\s+"(.*)"', s, re.I)
        if m:
            txt = bytes(m.group(2), 'utf-8').decode('unicode_escape').encode('latin-1')
            sym[m.group(1)] = len(consts); consts += txt + b'\0'; continue
        m = re.fullmatch(r'(\w+)\s+EQU\s+(\S+)', s, re.I)
        if m: sym[m.group(1)] = num(m.group(2), sym); continue
        lineas.append(s)
    return lineas, tams, consts, sym

def ensamblar(lineas, sym, pasada):
    code, rot = [], {}
    for l in lineas:
        m = re.match(r'(\w+):\s*(.*)', l)
        if m:
            rot[m.group(1)] = len(code); l = m.group(2)
            if not l: continue
        partes = l.split(None, 1)
        mn = partes[0].upper()
        ops = [o for o in re.split(r',(?![^\[]*\])', partes[1])] if len(partes) > 1 else []
        tabla = dict(sym); tabla.update(pasada)
        enc = [operando(o, tabla) for o in ops]
        o = OPC[mn]
        if len(enc) == 2:
            (ta, ba), (tb, bb) = enc
            code += [(tb << 6) | (ta << 4) | o] + bb + ba
        elif len(enc) == 1:
            ta, ba = enc[0]
            code += [(ta << 6) | o] + ba
        else:
            code += [o]
    return code, rot

def main():
    entrada, salida = sys.argv[1], sys.argv[2]
    version = 2
    for a in sys.argv[3:]:
        if a.startswith('v='): version = int(a[2:])
    lineas, tams, consts, sym = parse(entrada)
    global PRIMERA
    _, rot = ensamblar(lineas, sym, {})
    PRIMERA = False
    code, rot = ensamblar(lineas, sym, rot)
    w = lambda v: [(v >> 8) & 0xFF, v & 0xFF]
    if version == 1:
        hdr = b'VMX26' + bytes([1] + w(len(code)))
        open(salida, 'wb').write(hdr + bytes(code))
    else:
        hdr = b'VMX26' + bytes([2] + w(len(code)) + w(tams['DATA']) + w(tams['EXTRA']) + w(tams['STACK'])
                               + w(len(consts)) + w(rot.get('main', 0)))
        open(salida, 'wb').write(hdr + bytes(code) + consts)

if __name__ == '__main__':
    main()

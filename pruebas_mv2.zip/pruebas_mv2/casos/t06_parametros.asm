; T06 - Param Segment y pila inicial: imprime argc y cada argv[i] (incluido el nombre del .vmx)
; Ejecutar con: -p prueba 01 2   -> Esperado: argc = 4 y las 4 cadenas, una por linea
; Sin -p                          -> Esperado: argc = 0 y nada mas
NL EQU "\n"
\\DATA 16
main: MOV EEX, [SP+4]       ; argc
      MOV [DS+0], EEX
      MOV EDX, DS
      LDH ECX, 4
      LDL ECX, 1
      MOV EAX, 1
      SYS 2
      MOV EBX, [SP+8]       ; puntero al arreglo argv (o -1)
ciclo: CMP EEX, 0
      JZ fin
      MOV EDX, [EBX+0]      ; argv[i] -> puntero al string en el Param Segment
      SYS 4
      MOV EDX, KS
      ADD EDX, NL
      SYS 4
      ADD EBX, 4
      SUB EEX, 1
      JMP ciclo
fin:  RET

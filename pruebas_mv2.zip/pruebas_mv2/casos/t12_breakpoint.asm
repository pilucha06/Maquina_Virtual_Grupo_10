; T12 - Breakpoint (SYS 15) e imagen .vmi
; Guarda 77, hace SYS 15 y despues lo imprime.
\\DATA 16
main: MOV [DS+0], 77
      SYS 15
      MOV EDX, DS
      LDH ECX, 4
      LDL ECX, 1
      MOV EAX, 1
      SYS 2
      STOP

; T01 - Subrutinas y pila: factorial recursivo de 5 con pasaje de parametros por pila
; Prueba: CALL, RET, PUSH, POP, BP para acceder a parametros, MUL, saltos, entry point (main)
; Esperado: imprime 120
\\DATA 16
fact:     PUSH BP
          MOV BP, SP
          MOV EAX, [BP+8]       ; n (BP+0 = BP viejo, BP+4 = dir. de retorno)
          CMP EAX, 1
          JNP caso_base         ; n <= 1
          SUB EAX, 1
          PUSH EAX
          CALL fact             ; EAX = (n-1)!
          ADD SP, 4
          MUL EAX, [BP+8]       ; EAX = n * (n-1)!
          JMP fin_fact
caso_base: MOV EAX, 1
fin_fact: MOV SP, BP
          POP BP
          RET
main:     PUSH 5
          CALL fact
          ADD SP, 4
          MOV [DS+0], EAX
          MOV EDX, DS
          LDH ECX, 4
          LDL ECX, 1
          MOV EAX, 1
          SYS 2
          RET                   ; vuelve a la direccion -1 -> fin del proceso

; T04 - Constantes string en el Const Segment, SYS 4 y el disassembler (-d)
; Con -d se deben ver las 3 constantes con el formato del PDF:
;   la primera con 6 bytes + ".." (mide mas de 7), la segunda con '.' en los no imprimibles
TITULO EQU "Fund. de la Arq. de Computadoras\n"
RARO   EQU "abc\x08\x0a\x0d"
CORTO  EQU "MV2"
NL     EQU "\n"
main: MOV EDX, KS
      ADD EDX, TITULO
      SYS 4
      MOV EDX, KS
      ADD EDX, CORTO
      SYS 4
      MOV EDX, KS
      ADD EDX, NL
      SYS 4
      STOP

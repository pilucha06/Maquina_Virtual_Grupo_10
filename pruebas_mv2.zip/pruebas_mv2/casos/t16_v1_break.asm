; T16 - Programa v1 con SYS 15 (como sample_2 de la catedra) y basura en los bits reservados
; Se traduce como v1. Guarda 55 en [EDX+0] con los bits reservados en 111.
\\DATA 16
main: MOV EDX, DS
      MOV [EDX+0], 55
      SYS 15
      LDH ECX, 4
      LDL ECX, 1
      MOV EAX, 1
      SYS 2
      STOP

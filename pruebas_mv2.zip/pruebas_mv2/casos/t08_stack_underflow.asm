; T08 - POP de mas -> Error: Stack Underflow
; La pila arranca con 3 valores (RET, argc, argv): el cuarto POP no tiene de donde sacar
main: POP EAX
      POP EAX
      POP EAX
      POP EAX
      STOP

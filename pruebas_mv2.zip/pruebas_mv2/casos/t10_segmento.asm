; T10 - Acceso fuera del Extra Segment -> Error: Falla de segmento
\\EXTRA 16
main: MOV EAX, [ES+14]       ; 14..17 se pasa del segmento (mide 16)
      STOP

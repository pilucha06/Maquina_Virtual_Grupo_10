; T09 - Division por cero -> Error: Division por cero
main: MOV EAX, 10
      MOV EBX, 0
      DIV EAX, EBX
      STOP

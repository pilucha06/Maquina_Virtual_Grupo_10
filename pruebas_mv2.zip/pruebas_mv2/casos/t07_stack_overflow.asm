; T07 - Recursion infinita -> Error: Stack Overflow
\\STACK 64
main: CALL main

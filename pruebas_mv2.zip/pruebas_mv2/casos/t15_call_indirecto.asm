; T15 - CALL con operando de registro y de memoria (no solo con rotulo)
; Esperado: imprime "A", "B" y "C" (una por linea) y termina con RET
A EQU "A\n"
B EQU "B\n"
C EQU "C\n"
\\DATA 16
subA: MOV EDX, KS
      ADD EDX, A
      SYS 4
      RET
subB: MOV EDX, KS
      ADD EDX, B
      SYS 4
      RET
subC: MOV EDX, KS
      ADD EDX, C
      SYS 4
      RET
main: CALL subA            ; CALL con inmediato (rotulo)
      MOV EAX, subB
      CALL EAX             ; CALL con registro
      MOV [DS+0], subC
      CALL [DS+0]          ; CALL con memoria
      RET

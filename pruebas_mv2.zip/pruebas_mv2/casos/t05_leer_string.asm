; T05 - SYS 3 (STRING READ) con limite y sin limite, y SYS 4 para mostrarlo
; Entrada: "Hola mundo" y "sin limite"  -> Esperado: "Hola" (ECX=4) y "sin limite" (ECX=-1)
NL EQU "\n"
\\DATA 64
main: MOV EDX, DS
      MOV ECX, 4
      SYS 3                 ; lee como maximo 4 caracteres -> "Hola" + '\0'
      SYS 4
      MOV EDX, KS
      ADD EDX, NL
      SYS 4
      MOV EDX, DS
      ADD EDX, 20
      MOV ECX, -1
      SYS 3                 ; sin limite
      SYS 4
      MOV EDX, KS
      ADD EDX, NL
      SYS 4
      STOP

; T03 - Modificadores de memoria b[] w[] l[] (big endian, truncado y extension de signo)
; Esperado (hexa y decimal), DS arranca despues del codigo:
;   DS+0  = 0x11223344            (MOV [DS+0], EAX con EAX = 0x11223344)
;   DS+4  = 0x0                   (no se usa)
;   DS+8  = 0x44003344            (b[DS+8] <- EAX guarda 0x44; w[DS+10] <- EAX guarda 0x3344)
;   DS+12 = 0x11 17               (EBX <- b[DS+0]: el primer byte es el mas significativo)
;   DS+16 = 0x3344 13124          (ECX <- w[DS+2])
;   MOV w[DS+2], l[DS+8]: toma los 2 bytes bajos de 0x44003344 (33 44) -> DS+0 sigue 0x11223344
;   MOV w[DS+0], -2: escribe FF FE en los bytes 0 y 1 -> DS+0 = 0xFFFE3344 -117948
\\DATA 32
main: LDH EAX, 0x1122
      LDL EAX, 0x3344
      MOV [DS+0], EAX
      MOV EBX, b[DS+0]
      MOV ECX, w[DS+2]
      MOV b[DS+8], EAX
      MOV w[DS+10], EAX
      MOV [DS+12], EBX
      MOV [DS+16], ECX
      MOV EDX, DS
      LDH ECX, 4
      LDL ECX, 5
      MOV EAX, 9
      SYS 2                 ; imprime DS+0, +4, +8, +12, +16 (l)
      MOV w[DS+2], l[DS+8]  ; l[8] = 00 00 33 44 -> w toma los 2 bytes bajos (33 44)
      LDH ECX, 4
      LDL ECX, 1
      SYS 2                 ; DS+0 = 0x11223344 (los bytes 2-3 ya eran 33 44)
      MOV w[DS+0], -2       ; FF FE en los bytes 0 y 1
      SYS 2                 ; DS+0 = 0xFFFE3344
      STOP

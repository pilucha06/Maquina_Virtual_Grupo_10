; T13 - Sin rotulo main: arranca en la primera instruccion; termina con RET (sin STOP)
NL EQU "OK sin main\n"
      MOV EDX, KS
      SYS 4
      RET

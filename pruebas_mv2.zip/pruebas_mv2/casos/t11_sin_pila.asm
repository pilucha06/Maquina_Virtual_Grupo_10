; T11 - \\STACK 0: el header es invalido (la pila es obligatoria) -> ERROR de header
\\STACK 0
main: STOP

; T14 - SYS 1 (leer numero) seguido de SYS 3 (leer string) y de un breakpoint
; Entrada: "42" / "texto" / "q"
; Esperado: guarda 42, lee "texto", imprime "texto", y en el breakpoint espera la 'q' (sale sin imprimir el 42)
NL EQU "\n"
\\DATA 64
main: MOV EDX, DS
      LDH ECX, 4
      LDL ECX, 1
      MOV EAX, 1
      SYS 1                 ; lee un decimal en DS+0
      ADD EDX, 8
      MOV ECX, -1
      SYS 3                 ; lee un string en DS+8
      SYS 4
      MOV EDX, KS
      ADD EDX, NL
      SYS 4
      SYS 15
      MOV EDX, DS
      LDH ECX, 4
      LDL ECX, 1
      MOV EAX, 1
      SYS 2
      STOP

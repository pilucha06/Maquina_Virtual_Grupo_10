; T02 - Sectores de registro (EAX / AX / AL / AH) y el ejemplo PUSH AX / POP w[ES+4] del PDF
; Esperado (hexa y decimal):
;   EBX = AL  -> 0xFFFFFFCD -51        (extiende el signo de 1 byte)
;   ECX = AH  -> 0xFFFFFFAB -85
;   EDX = AX  -> 0xFFFFABCD -21555     (extiende el signo de 2 bytes)
;   EAX luego de MOV AL,0x7F / MOV AH,0 / ... -> 0x1234007F 305397887 (no pisa el resto)
;   w[ES+4] luego de PUSH AX / POP w[ES+4]   -> 0xABCD -21555
\\DATA 32
main: LDH EAX, 0x1234
      LDL EAX, 0xABCD
      MOV EBX, AL
      MOV ECX, AH
      MOV EDX, AX
      MOV [DS+0], EBX
      MOV [DS+4], ECX
      MOV [DS+8], EDX
      PUSH AX               ; 0xFFFFABCD en la pila
      POP w[ES+4]           ; ES[4]=AB ES[5]=CD
      MOV AL, 0x7F
      MOV AH, 0
      MOV [DS+12], EAX
      MOV EDX, DS
      LDH ECX, 4
      LDL ECX, 4
      MOV EAX, 9            ; hexa + decimal
      SYS 2
      MOV EDX, ES
      ADD EDX, 4
      LDH ECX, 2
      LDL ECX, 1
      SYS 2
      STOP
